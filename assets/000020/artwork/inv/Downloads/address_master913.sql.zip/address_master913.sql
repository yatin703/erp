-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 04, 2017 at 05:10 PM
-- Server version: 5.1.47
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `neo`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `address_master`
-- 

CREATE TABLE `address_master` (
  `company_id` varchar(15) NOT NULL DEFAULT '',
  `short_id` varchar(15) DEFAULT NULL,
  `ref_comp_id` varchar(15) DEFAULT NULL,
  `name1` varchar(150) DEFAULT NULL,
  `name2` varchar(100) DEFAULT NULL,
  `name3` varchar(500) DEFAULT NULL,
  `street` varchar(150) DEFAULT NULL,
  `zip_code` varchar(10) DEFAULT NULL,
  `city_code` varchar(10) DEFAULT NULL,
  `country_id` varchar(12) DEFAULT NULL,
  `post_box_code` varchar(50) DEFAULT NULL,
  `post_box_no` varchar(50) DEFAULT NULL,
  `telephone1` varchar(50) DEFAULT NULL,
  `telephone2` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `railway_stn_no` varchar(50) DEFAULT NULL,
  `head_office` varchar(15) DEFAULT NULL,
  `industry_id` varchar(15) DEFAULT NULL,
  `sales_representative` varchar(255) DEFAULT NULL,
  `archive` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` varchar(15) DEFAULT NULL,
  `info_flag` int(11) DEFAULT NULL,
  `contact_date` date DEFAULT NULL,
  `adr_company_id` varchar(15) NOT NULL DEFAULT '',
  `strno` varchar(9) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `isdn_local` varchar(50) DEFAULT NULL,
  `isdn_euro` varchar(50) DEFAULT NULL,
  `name_owner1` varchar(50) DEFAULT NULL,
  `name_owner2` varchar(50) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `title_id` varchar(15) DEFAULT NULL,
  `salut_id` varchar(15) DEFAULT NULL,
  `home_page` varchar(100) DEFAULT '0',
  `incr51` int(4) DEFAULT '0',
  `incr98` int(4) DEFAULT '0',
  `incr319` int(4) DEFAULT '0',
  `incr73` int(4) DEFAULT '0',
  `incr75` int(4) DEFAULT '0',
  `incr76` int(4) DEFAULT '0',
  `incr79` int(4) DEFAULT '0',
  `incr82` int(4) DEFAULT '0',
  `incr85` int(4) DEFAULT '0',
  `incr87` int(4) DEFAULT '0',
  `incr89` int(4) DEFAULT '0',
  `incr70` int(4) DEFAULT '0',
  `incr138` int(4) DEFAULT '0',
  `incr143` int(4) DEFAULT '0',
  `incr145` int(4) DEFAULT '0',
  `incr320` int(4) unsigned DEFAULT '0',
  `default_dept` varchar(15) DEFAULT NULL,
  `incr298` int(4) DEFAULT NULL,
  `incr350` int(4) DEFAULT NULL,
  `own_contact_person` varchar(15) DEFAULT NULL,
  `anniversary_date` date DEFAULT NULL,
  `company_type` varchar(15) DEFAULT '0',
  `incr355` int(4) unsigned DEFAULT '0',
  `incr141` int(4) DEFAULT NULL,
  `district` varchar(25) DEFAULT '0',
  `taluka` varchar(25) DEFAULT '0',
  `relate_company` varchar(500) DEFAULT NULL,
  `incr416` int(4) unsigned DEFAULT '0',
  `vat_tin` varchar(30) DEFAULT NULL,
  `cst_tin` varchar(30) DEFAULT NULL,
  `city_name_id` varchar(15) DEFAULT NULL,
  `telephone1_info` varchar(30) DEFAULT NULL,
  `telephone2_info` varchar(30) DEFAULT NULL,
  `fax_info` varchar(30) DEFAULT NULL,
  `email_info` varchar(200) DEFAULT NULL,
  `transit_days` int(11) unsigned DEFAULT '0',
  `local_party` tinyint(1) NOT NULL DEFAULT '0',
  `email_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`company_id`,`adr_company_id`),
  KEY `company_id` (`company_id`),
  KEY `short_id` (`short_id`),
  KEY `ref_comp_id` (`ref_comp_id`),
  KEY `name1` (`name1`),
  KEY `name2` (`name2`),
  KEY `name3` (`name3`),
  KEY `adr_company_id` (`adr_company_id`),
  KEY `for_sales_bi_Tools1` (`adr_company_id`,`city_name_id`,`zip_code`,`country_id`,`company_id`,`archive`),
  KEY `for_purchase_bi_Tools1` (`adr_company_id`,`city_name_id`,`name1`,`zip_code`,`country_id`,`street`,`strno`,`name2`,`name3`,`taluka`,`district`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `address_master`
-- 

INSERT INTO `address_master` (`company_id`, `short_id`, `ref_comp_id`, `name1`, `name2`, `name3`, `street`, `zip_code`, `city_code`, `country_id`, `post_box_code`, `post_box_no`, `telephone1`, `telephone2`, `fax`, `railway_stn_no`, `head_office`, `industry_id`, `sales_representative`, `archive`, `user_id`, `info_flag`, `contact_date`, `adr_company_id`, `strno`, `email`, `isdn_local`, `isdn_euro`, `name_owner1`, `name_owner2`, `dob`, `title_id`, `salut_id`, `home_page`, `incr51`, `incr98`, `incr319`, `incr73`, `incr75`, `incr76`, `incr79`, `incr82`, `incr85`, `incr87`, `incr89`, `incr70`, `incr138`, `incr143`, `incr145`, `incr320`, `default_dept`, `incr298`, `incr350`, `own_contact_person`, `anniversary_date`, `company_type`, `incr355`, `incr141`, `district`, `taluka`, `relate_company`, `incr416`, `vat_tin`, `cst_tin`, `city_name_id`, `telephone1_info`, `telephone2_info`, `fax_info`, `email_info`, `transit_days`, `local_party`, `email_status`) VALUES 
('000020', '', '', 'GODREJ CONSUMER PRODUCTS LTD', '', 'GUWAHATI LOKHRA UNIT, LALUNG GAON, LOKHRA, GUWAHATI, 781 034, ASSAM', '', 'AS', '', '1', 'AABCG3365J', 'AABCG3365JEM017', '', '', '', 'GUWAHATI', '', '', 'EMP005|', 0, 'EMP022', NULL, '2011-04-14', '913', '', 'siddhi.more@godrejcp.com,', '18AABCG3365J6ZC', 'RANGE-III', '', '', '0000-00-00', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', NULL, NULL, '', '0000-00-00', '', 0, NULL, '', '', '', 0, '18570142373', '18319933876', '', '', '', '', '', 10, 0, 0);
-- Functions
-- 

CREATE DEFINER=`root`@`localhost` FUNCTION `strSplit`(x varchar(255), delim varchar(12), pos int) RETURNS varchar(255) CHARSET latin1
return replace(substring(substring_index(x, delim, pos), length(substring_index(x, delim, pos - 1)) + 1), delim, '')

